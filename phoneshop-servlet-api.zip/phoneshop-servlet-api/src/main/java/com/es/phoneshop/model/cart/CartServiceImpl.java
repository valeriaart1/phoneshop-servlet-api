package com.es.phoneshop.model.cart;

import com.es.phoneshop.model.product.Product;
import com.es.phoneshop.model.product.ProductDao;
import com.es.phoneshop.model.product.ProductDaoImpl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.*;

public class CartServiceImpl implements CartService {
    private static final String CART_SESSION_ATTRIBUTE = "cart";
    private ProductDao productDao = ProductDaoImpl.getInstance();
    private static volatile CartServiceImpl instance;

    private CartServiceImpl() {
    }

    public static CartServiceImpl getInstance() {
        if(instance == null) {
            synchronized (CartServiceImpl.class) {
                if(instance == null) {
                    instance = new CartServiceImpl();
                }
            }
        }
        return instance;
    }

    @Override
    public Cart getCart(HttpServletRequest request) {
        Cart result = (Cart) request.getSession().getAttribute(CART_SESSION_ATTRIBUTE);
        if(result == null) {
            result = new Cart();
            request.getSession().setAttribute(CART_SESSION_ATTRIBUTE, result);
        }
        return result;
    }

    @Override
    public String add(HttpSession session, Cart cart, Long productId, String quantity, Locale locale) {
        Product product = productDao.getProduct(productId).get();
        String errorOfQuantity = quantityHasError(locale, quantity, product.getStock());
        if(errorOfQuantity == null) {
            int quantityInt = Integer.parseInt(quantity);
            Optional<CartItem> optionalCartItem = cart
                    .getCartItems()
                    .stream()
                    .filter(cartItem -> cartItem.getProduct().getId().equals(product.getId()))
                    .findFirst();
            if (optionalCartItem.isPresent()) {
                CartItem cartItem = optionalCartItem.get();
                cartItem.setQuantity(cartItem.getQuantity() + quantityInt);
            } else {
                cart.getCartItems().add(new CartItem(product, quantityInt));
            }
            recalculateCart(cart);
            return null;
        }
        else {
            return errorOfQuantity;
        }
    }

    @Override
    public Map<Long, String> update(HttpSession session, Cart cart, String[] productIds, String[] quantities, Locale locale) {
        Map<Long, String> errors = new HashMap();

        for(int i = 0; i < productIds.length; i++) {
            Product product = productDao.getProduct(Long.valueOf(productIds[i])).get();
            String errorOfQuantity = quantityHasError(locale, quantities[i], product.getStock());
            if(errorOfQuantity == null) {
                int quantityInt = Integer.parseInt(quantities[i]);
                cart.getCartItems()
                        .stream()
                        .filter(cartItem -> cartItem.getProduct().getId().equals(product.getId()))
                        .findAny()
                        .ifPresent(cartItem -> cartItem.setQuantity(quantityInt));
                recalculateCart(cart);
            }
            else {
                errors.put(Long.valueOf(productIds[i]), errorOfQuantity);
            }
        }
        return errors;
    }

    private String quantityHasError(Locale locale, String quantity, int stock) {
        try {
            int quantityInt = Integer.parseInt(String.valueOf(NumberFormat.getInstance(locale).parse(quantity)));
            if (quantityInt < 0) {
                return "Quantity must be positive!";
            }
            if (quantityInt > stock) {
                return "Error of stock! Max stock = " + stock;
            }
        }
        catch(ParseException exception) {
            return "Not a number";
        }
        return null;
    }

    @Override
    public void delete(Cart cart, Product product) {
        Optional<CartItem> optionalCartItem = cart
                .getCartItems()
                .stream()
                .filter(cartItem -> cartItem.getProduct().getId().equals(product.getId()))
                .findFirst();
        cart.setTotalQuantity(cart.getTotalQuantity() - optionalCartItem.get().getQuantity());
        BigDecimal oldProductPrice = product.getPrice().multiply(new BigDecimal(optionalCartItem.get().getQuantity()));
        cart.setTotalCost(cart.getTotalCost().subtract(oldProductPrice));
        cart.getCartItems().removeIf(cartItem -> product.equals(cartItem.getProduct()));
    }

    private void recalculateCart(Cart cart, Product product, int quantity) {
        BigDecimal productPrice = product.getPrice().multiply(new BigDecimal(quantity));
        cart.setTotalCost(cart.getTotalCost().add(productPrice));
        cart.setTotalQuantity(cart.getTotalQuantity() + quantity);
    }

    private void recalculateCart(Cart cart) {
        BigDecimal totalCost = new BigDecimal(
                cart.getCartItems()
                        .stream()
                        .mapToLong(cartItem -> cartItem.getQuantity() * cartItem.getProduct().getPrice().longValue()).sum());
        int totalQuantity = (int) cart.getCartItems()
                .stream()
                .mapToLong(CartItem::getQuantity)
                .sum();
        cart.setTotalCost(totalCost);
        cart.setTotalQuantity(totalQuantity);
    }
}